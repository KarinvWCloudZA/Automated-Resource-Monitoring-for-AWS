import json
import urllib.parse
import boto3

print('Loading function')

s3 = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')

# Regions to filter
ALLOWED_REGIONS = ['us-east-1', 'af-south-1', 'eu-west-1']

def lambda_handler(event, context):
    # Get the bucket name and object key from the event
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'], encoding='utf-8')
    
    # Check if the file name contains one of the allowed regions
    if not any(region in key for region in ALLOWED_REGIONS):
        print(f"Skipping file {key} as it does not contain an allowed region.")
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': f"File {key} skipped. Does not contain an allowed region."
            })
        }
    
    try:
        # Get object metadata
        response = s3.head_object(Bucket=bucket, Key=key)
        
        # Extract required details
        file_name = key
        bucket_name = bucket
        upload_timestamp = response['LastModified']
        object_size = response['ContentLength']
        object_url = f"https://{bucket}.s3.amazonaws.com/{key}"
        
        # Print the details
        print(f"File Name: {file_name}")
        print(f"Bucket Name: {bucket_name}")
        print(f"Upload Timestamp: {upload_timestamp}")
        print(f"Object Size: {object_size} bytes")
        print(f"Object URL: {object_url}")
        
        # Write to DynamoDB
        table = dynamodb.Table('KeyEvents')
        table.put_item(
            Item={
                'file_name': file_name,
                'bucket_name': bucket_name,
                'upload_timestamp': str(upload_timestamp),
                'object_size': object_size,
                'object_url': object_url
            }
        )
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Successfully added to DynamoDB',
                'FileName': file_name,
                'BucketName': bucket_name,
                'UploadTimestamp': str(upload_timestamp),
                'ObjectSize': object_size,
                'ObjectURL': object_url
            })
        }
    except Exception as e:
        print(e)
        print(f'Error processing object {key} from bucket {bucket}.')
        raise e